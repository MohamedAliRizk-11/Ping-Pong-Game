# -*- coding: utf-8 -*-
"""
Created on Fri Apr 24 03:47:16 2026

@author: Mohamed Ali
"""

'''

import pygame
import sys
import random
import os

pygame.init()

# ================= SCREEN =================
WIDTH, HEIGHT = 800, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ping Pong Fixed Fire System")
clock = pygame.time.Clock()

WHITE = (255, 255, 255)

# ================= PATH =================
BASE_DIR = os.path.dirname(__file__)

# ================= LOAD IMAGES =================
fire_img = pygame.image.load(os.path.join(BASE_DIR, "fire.png")).convert_alpha()
ice_img = pygame.image.load(os.path.join(BASE_DIR, "snow.png")).convert_alpha()
scissors_img = pygame.image.load(os.path.join(BASE_DIR, "cut.png")).convert_alpha()

fire_img = pygame.transform.scale(fire_img, (30, 30))
ice_img = pygame.transform.scale(ice_img, (30, 30))
scissors_img = pygame.transform.scale(scissors_img, (30, 30))

icon_size = (18, 18)
fire_icon = pygame.transform.scale(fire_img, icon_size)
ice_icon = pygame.transform.scale(ice_img, icon_size)
scissors_icon = pygame.transform.scale(scissors_img, icon_size)

# ================= PLAYERS =================
player = pygame.Rect(20, HEIGHT//2 - 40, 10, 80)
ai = pygame.Rect(WIDTH - 30, HEIGHT//2 - 40, 10, 80)

player_h = 80
ai_h = 80

# ================= BALL =================
ball = pygame.Rect(WIDTH//2, HEIGHT//2, 12, 12)

base_speed = 6
speed_x = base_speed * random.choice([-1, 1])
speed_y = base_speed * random.choice([-1, 1])

# ================= SCORE =================
player_score = 0
ai_score = 0
font = pygame.font.SysFont(None, 50)

# ================= ITEMS =================
def spawn_item():
    return pygame.Rect(
        random.randint(60, WIDTH - 60),
        random.randint(60, HEIGHT - 60),
        30, 30
    )

fire = spawn_item()
ice = spawn_item()
scissors = spawn_item()

# ================= SPEED BOOST FUNCTION =================
def boost_speed():
    global speed_x, speed_y
    speed_x *= 1.8
    speed_y *= 1.8

# ================= STATES =================
player_frozen = False
ai_frozen = False
freeze_p = 0
freeze_ai = 0

player_cut = False
ai_cut = False

ball_fire_active = False
ball_fire_owner = None

# ================= DRAW LIST =================
def draw_list(x, y, effects):
    box = pygame.Surface((120, 30), pygame.SRCALPHA)
    box.fill((70, 70, 70, 120))
    screen.blit(box, (x, y))

    xx = x + 5
    for icon in effects:
        screen.blit(icon, (xx, y + 6))
        xx += 20

# ================= LOOP =================
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    player.centery = pygame.mouse.get_pos()[1]

    # ================= AI =================
    if not ai_frozen:
        if ball.centery > ai.centery:
            ai.y += 5
        else:
            ai.y -= 5

    ai.y = max(0, min(HEIGHT - ai.height, ai.y))

    # ================= BALL =================
    ball.x += speed_x
    ball.y += speed_y

    if ball.top <= 0 or ball.bottom >= HEIGHT:
        speed_y *= -1

    # ================= PLAYER HIT =================
    if ball.colliderect(player):
        ball.left = player.right
        speed_x = abs(speed_x)

        offset = (ball.centery - player.centery) / (player.height / 2)
        speed_y = offset * 6

        if ball_fire_active:
            boost_speed()

        ball_fire_active = False
        ball_fire_owner = None

    # ================= AI HIT =================
    if ball.colliderect(ai):
        ball.right = ai.left
        speed_x = -abs(speed_x)

        offset = (ball.centery - ai.centery) / (ai.height / 2)
        speed_y = offset * 6

        if ball_fire_active:
            boost_speed()

        ball_fire_active = False
        ball_fire_owner = None

    # ================= FIRE ITEM (FIX HERE 🔥) =================
    if ball.colliderect(fire):
        ball_fire_active = True

        if speed_x > 0:
            ball_fire_owner = "ai"
        else:
            ball_fire_owner = "player"

        boost_speed()   # 🔥 هنا الحل الحقيقي
        fire = spawn_item()

    # ================= ICE =================
    if ball.colliderect(ice):
        if speed_x > 0:
            ai_frozen = True
            freeze_ai = 120
        else:
            player_frozen = True
            freeze_p = 120
        ice = spawn_item()

    # ================= SCISSORS =================
    if ball.colliderect(scissors):
        if speed_x > 0:
            ai_cut = True
            ai.height = player_h // 2
        else:
            player_cut = True
            player.height = player_h // 2
        scissors = spawn_item()

    # ================= FREEZE =================
    if freeze_p > 0:
        freeze_p -= 1
        if freeze_p == 0:
            player_frozen = False

    if freeze_ai > 0:
        freeze_ai -= 1
        if freeze_ai == 0:
            ai_frozen = False

    # ================= GOAL =================
    if ball.left <= 0:
        ai_score += 1
        ball.center = (WIDTH//2, HEIGHT//2)
        speed_x = base_speed
        speed_y = random.choice([-base_speed, base_speed])

        player.height = player_h
        ai.height = ai_h

        player_cut = False
        ai_cut = False

        ball_fire_active = False
        ball_fire_owner = None

    if ball.right >= WIDTH:
        player_score += 1
        ball.center = (WIDTH//2, HEIGHT//2)
        speed_x = -base_speed
        speed_y = random.choice([-base_speed, base_speed])

        player.height = player_h
        ai.height = ai_h

        player_cut = False
        ai_cut = False

        ball_fire_active = False
        ball_fire_owner = None

    # ================= DRAW =================
    screen.fill((0, 0, 0))

    pygame.draw.rect(screen, WHITE, player)
    pygame.draw.rect(screen, WHITE, ai)
    pygame.draw.ellipse(screen, WHITE, ball)

    screen.blit(fire_img, (fire.x, fire.y))
    screen.blit(ice_img, (ice.x, ice.y))
    screen.blit(scissors_img, (scissors.x, scissors.y))

    score = font.render(f"{player_score} : {ai_score}", True, WHITE)
    screen.blit(score, (WIDTH//2 - 40, 10))

    player_effects = []
    ai_effects = []

    if ball_fire_active:
        if ball_fire_owner == "player":
            player_effects.append(fire_icon)
        elif ball_fire_owner == "ai":
            ai_effects.append(fire_icon)

    if player_frozen:
        player_effects.append(ice_icon)
    if ai_frozen:
        ai_effects.append(ice_icon)

    if player_cut:
        player_effects.append(scissors_icon)
    if ai_cut:
        ai_effects.append(scissors_icon)

    draw_list(WIDTH//2 - 220, 10, player_effects)
    draw_list(WIDTH//2 + 60, 10, ai_effects)

    pygame.display.flip()
    clock.tick(60)
    
    '''
    
import pygame
import sys
import random
import os
from collections import deque

pygame.init()

# ================= SCREEN =================
WIDTH, HEIGHT = 800, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ping Pong AI BFS Project")
clock = pygame.time.Clock()

WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

BASE_DIR = os.path.dirname(__file__)

# ================= IMAGES =================
fire_img = pygame.image.load(os.path.join(BASE_DIR, "fire.png")).convert_alpha()
ice_img = pygame.image.load(os.path.join(BASE_DIR, "snow.png")).convert_alpha()
scissors_img = pygame.image.load(os.path.join(BASE_DIR, "cut.png")).convert_alpha()

fire_img = pygame.transform.scale(fire_img, (30, 30))
ice_img = pygame.transform.scale(ice_img, (30, 30))
scissors_img = pygame.transform.scale(scissors_img, (30, 30))

icon_size = (18, 18)
fire_icon = pygame.transform.scale(fire_img, icon_size)
ice_icon = pygame.transform.scale(ice_img, icon_size)
scissors_icon = pygame.transform.scale(scissors_img, icon_size)

# ================= PLAYERS =================
player_default_h = 80
ai_default_h = 80

player = pygame.Rect(20, HEIGHT//2 - 40, 10, player_default_h)
ai = pygame.Rect(WIDTH - 30, HEIGHT//2 - 40, 10, ai_default_h)

# ================= BALL =================
ball = pygame.Rect(WIDTH//2, HEIGHT//2, 12, 12)

base_speed = 6
speed_x = base_speed * random.choice([-1, 1])
speed_y = base_speed * random.choice([-1, 1])

# ================= SCORE =================
player_score = 0
ai_score = 0
font = pygame.font.SysFont(None, 50)

# ================= ITEMS =================
def spawn_item():
    return pygame.Rect(
        random.randint(60, WIDTH - 60),
        random.randint(60, HEIGHT - 60),
        30, 30
    )

fire = spawn_item()
ice = spawn_item()
scissors = spawn_item()

# ================= STATES =================
ball_fire = False

player_frozen = False
ai_frozen = False
freeze_p = 0
freeze_ai = 0

player_cut = False
ai_cut = False

# ================= SPEED BOOST =================
def boost_speed():
    global speed_x, speed_y
    speed_x *= 1.3
    speed_y *= 1.3

# ================= BFS AI (CONTROL LOGIC) =================
def bfs_ai(ai_rect, ball_rect):
    queue = deque()
    visited = set()

    start = ai_rect.centery
    target = ball_rect.centery

    queue.append((start, 0))
    visited.add(start)

    while queue:
        pos, depth = queue.popleft()

        if abs(pos - target) < 8:
            return pos

        if depth > 8:
            continue

        for move in [-6, 0, 6]:
            new_pos = pos + move

            if 0 <= new_pos <= HEIGHT and new_pos not in visited:
                visited.add(new_pos)
                queue.append((new_pos, depth + 1))

    return start

# ================= EFFECT UI =================
def draw_list(x, y, effects):
    box = pygame.Surface((140, 30), pygame.SRCALPHA)
    box.fill((70, 70, 70, 120))
    screen.blit(box, (x, y))

    xx = x + 5
    for icon in effects:
        screen.blit(icon, (xx, y + 6))
        xx += 20

# ================= GAME LOOP =================
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # ================= PLAYER =================
    player.centery = pygame.mouse.get_pos()[1]

    # ================= AI (BFS CONTROL) =================
    if not ai_frozen:
        target = bfs_ai(ai, ball)

        if ai.centery < target:
            ai.y += 5
        elif ai.centery > target:
            ai.y -= 5

    ai.y = max(0, min(HEIGHT - ai.height, ai.y))

    # ================= BALL =================
    ball.x += speed_x
    ball.y += speed_y

    if ball.top <= 0 or ball.bottom >= HEIGHT:
        speed_y *= -1

    # ================= COLLISIONS =================
    if ball.colliderect(player):
        ball.left = player.right
        speed_x = abs(speed_x)
        speed_y += random.uniform(-2, 2)

        if ball_fire:
            boost_speed()
        ball_fire = False

    if ball.colliderect(ai):
        ball.right = ai.left
        speed_x = -abs(speed_x)
        speed_y += random.uniform(-2, 2)

        if ball_fire:
            boost_speed()
        ball_fire = False

    # ================= FIRE =================
    if ball.colliderect(fire):
        ball_fire = True
        boost_speed()
        fire = spawn_item()

    # ================= ICE =================
    if ball.colliderect(ice):
        if speed_x > 0:
            ai_frozen = True
            freeze_ai = 120
        else:
            player_frozen = True
            freeze_p = 120
        ice = spawn_item()

    # ================= SCISSORS =================
    if ball.colliderect(scissors):
        if speed_x > 0:
            ai.height = player_default_h // 2
            ai_cut = True
        else:
            player.height = player_default_h // 2
            player_cut = True
        scissors = spawn_item()

    # ================= FREEZE TIMER =================
    if freeze_p > 0:
        freeze_p -= 1
        if freeze_p == 0:
            player_frozen = False

    if freeze_ai > 0:
        freeze_ai -= 1
        if freeze_ai == 0:
            ai_frozen = False

    # ================= GOALS =================
    if ball.left <= 0:
        ai_score += 1
        ball.center = (WIDTH//2, HEIGHT//2)
        speed_x = base_speed * random.choice([-1, 1])
        speed_y = base_speed * random.choice([-1, 1])

        player.height = player_default_h
        ai.height = ai_default_h

        player_cut = False
        ai_cut = False

    if ball.right >= WIDTH:
        player_score += 1
        ball.center = (WIDTH//2, HEIGHT//2)
        speed_x = base_speed * random.choice([-1, 1])
        speed_y = base_speed * random.choice([-1, 1])

        player.height = player_default_h
        ai.height = ai_default_h

        player_cut = False
        ai_cut = False

    # ================= DRAW =================
    screen.fill((0, 0, 0))

    pygame.draw.rect(screen, RED, player)
    pygame.draw.rect(screen, BLUE, ai)
    pygame.draw.ellipse(screen, WHITE, ball)

    screen.blit(fire_img, (fire.x, fire.y))
    screen.blit(ice_img, (ice.x, ice.y))
    screen.blit(scissors_img, (scissors.x, scissors.y))

    # SCORE
    score = font.render(f"{player_score} : {ai_score}", True, WHITE)
    screen.blit(score, (WIDTH//2 - 40, 10))

    # ================= EFFECT LISTS =================
    player_effects = []
    ai_effects = []

    if player_frozen:
        player_effects.append(ice_icon)
    if ai_frozen:
        ai_effects.append(ice_icon)

    if player_cut:
        player_effects.append(scissors_icon)
    if ai_cut:
        ai_effects.append(scissors_icon)

    draw_list(WIDTH//2 - 230, 10, player_effects)
    draw_list(WIDTH//2 + 70, 10, ai_effects)

    pygame.display.flip()
    clock.tick(60)